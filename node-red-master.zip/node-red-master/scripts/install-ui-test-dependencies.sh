npm install --no-save \
 grunt-webdriver@^2.0.3 \
 wdio-chromedriver-service@^0.1.5 \
 wdio-mocha-framework@^0.6.4 \
 wdio-spec-reporter@^0.1.5 \
 webdriverio@^4.14.4 \
 chromedriver \
 wdio-browserstack-service@^0.1.19 \
 browserstack-local@^1.4.4 \
 mosca@^2.8.3
